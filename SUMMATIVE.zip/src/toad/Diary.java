package toad;

public class Diary{
	
}