package toad;

import toad.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.Border;

public class Window extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1234567890L;
	private static InputStream stream = null;
	private static Font roboto = null;

	public JPanel container = null;
	public JTextField hud = null;
	public JLabel speaker = null;
	public JLabel name = null;
	public JLabel text = null;
	public JLabel image = null;
    private String input = "weegee";

	Window(String title){
		super(title);
		try{
			stream = new FileInputStream("font/Roboto-Medium.ttf");
			roboto =  Font.createFont(Font.TRUETYPE_FONT, stream);
			GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(roboto);
		}
		catch(FileNotFoundException e){}//Catch all the possible errors		
		catch(FontFormatException e){}
		catch(IOException e){}	

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Do nothing when they hit close, cause we got something special instead

        this.setPreferredSize(new Dimension(320, 520));//set window size
        this.setLocation(new Point(300, 5));//Set the location
        // this.setResizable(false);

        Border whiteBorder = BorderFactory.createLineBorder(Color.white, 6);

        container = new JPanel();
        container.setBackground(Color.black);
        container.setLayout(null);
        this.getContentPane().add(container);

        // hud = new JLabel("This is the hud", SwingConstants.CENTER);
        hud = new JTextField();
        hud.addActionListener(this);
        hud.setFocusable(true);
        hud.setSize(new Dimension(320, 50));
        hud.setLocation(new Point(0, 240));//Set the location
        hud.setOpaque(true);
        hud.setBackground(Color.gray);
        container.add(hud);

        speaker = new JLabel("", SwingConstants.CENTER);
        speaker.setSize(new Dimension(100, 150));
        speaker.setLocation(new Point(0, 290));//Set the location
        speaker.setOpaque(true);
        speaker.setBackground(Color.black);
        container.add(speaker);

        name = new JLabel("NPC Name", SwingConstants.CENTER);
        name.setSize(new Dimension(105, 45));
        name.setLocation(new Point(0, 440));//Set the location
        name.setOpaque(true);
        name.setBorder(whiteBorder);
        name.setBackground(Color.black);
        name.setForeground(Color.white);
        name.setFont(roboto.deriveFont(15f));
        container.add(name);

        text = new JLabel("This is the text box", SwingConstants.LEFT);
        text.setVerticalAlignment(SwingConstants.TOP);
        text.setSize(new Dimension(205, 195));
        // text.setMaxWidth(205)
        text.setLocation(new Point(100, 290));//Set the location
        text.setOpaque(true);
        text.setBackground(Color.black);
        text.setForeground(Color.white);
        text.setBorder(whiteBorder);
        text.setFont(roboto.deriveFont(15f));
        text.setFocusable(true);
        container.add(text);

        image = new JLabel("", SwingConstants.CENTER);
        image.setSize(new Dimension(320, 240));
        image.setLocation(new Point(0, 0));//Set the location
        image.setOpaque(true);
        image.setBorder(whiteBorder);
        image.setBackground(Color.black);
        container.add(image);

        try {
            // Set System L&F
	        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	        //UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
	    }
	    catch (UnsupportedLookAndFeelException e) {}//Catch all those pesky errors, which really should never show up anyways but it won't let me run the program if it doesn't have them
	    catch (ClassNotFoundException e) {}
	    catch (InstantiationException e) {}
	    catch (IllegalAccessException e) {}

	    
        this.pack();       
        this.setVisible(true);
	}

	void setDialog(String content){
		this.text.setText(content);
	}

	void setImage(String path){
		this.image.setIcon(new ImageIcon(path));
	}

	void setSprite(String path){
		this.speaker.setIcon(new StretchIcon(path));
	}

	void setNPCName(String name){
		this.name.setText(name);
	}

    public void actionPerformed(ActionEvent evt) {
        this.input = hud.getText();
    }

    String getInput(){
        if (!this.input.equals(null)) {
            return this.input;
        }
        else{
            return "no input";
        }
    }

}