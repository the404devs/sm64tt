package toad;
import toad.*;

public class StoryEvent{
	String eventText = null;
	String imagePath = null;
	String npcPath = null;
	String npcName = null;
	Boolean options = false;
	int nextChap = 0;
	String opt1 = "memes";
	String opt2 = null;
	String opt3 = null;
	String opt4 = null;

	StoryEvent(String story, String imgPath, String npcimgPath, String npcName, Boolean hasOptions, int nextChap, String opt1, String opt2, String opt3, String opt4){
		this.eventText = story;
		this.imagePath = imgPath;
		this.npcPath = npcimgPath;
		this.npcName = npcName;
		this.nextChap = nextChap;
		this.options = hasOptions;
		this.opt1 = opt1;
		this.opt2 = opt2;
		this.opt3 = opt3;
		this.opt4 = opt4;
	}

	// StoryEvent(String story, String imgPath, String npcimgPath, String npcName, Boolean hasOptions){
	// 	this.eventText = story;
	// 	this.imagePath = imgPath;
	// 	this.npcPath = npcimgPath;
	// 	this.npcName = npcName;
	// 	this.nextChap = 1;
	// 	this.options = hasOptions;
	// }

	String writeStory(){
		return this.eventText;
	}

	String getImage(){
		return this.imagePath;
	}

	String getSprite(){
		return this.npcPath;
	}

	String getNPCName(){
		return this.npcName;
	}

	Boolean autoAdvance(){
		return !this.options;
	}

	int getNextChap(){
		return this.nextChap;
	}

	String getOption(int option){
		if (option==1) {
			return this.opt1;
		}
		else if (option==2) {
			return this.opt2;
		}
		else if (option==3) {
			return this.opt3;
		}
		else if (option==4) {
			return this.opt4;
		}
		else{
			return null;
		}
	}
}