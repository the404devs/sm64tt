package toad;

public class DiaryPage{

}