package toad;

import toad.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;

public class game{

	private static void delay(){
        /*This tiny function is used to create a 2 second pause in the execution of the code. 
        Super useful to make it look like the computer is thinking,
        or just to, you know, delay things for a bit.*/     
        try{
            Thread.sleep(5000);//10 seconds
        }
        catch (InterruptedException e)
        {
            
            System.out.println("oh no the program broke. fix the delay function");
        }
    }

	public static void main(String[] args){
		Date startTime = new Date();//Get the time they started playing. WE compare this later to the time they ended to determine how long it took to win

		Window window = new Window("Super Mario 64: Toad's Terror");//Create a window
		ArrayList<String> allStory = new ArrayList<String>();//Arraylist to hold all the story details from the file
		int currentChap = 1;//Current chapter of the story. Starts at 1, cause thats the first chapter
		Boolean gameOn = true;//Are they playing?

		try{
			//Use bufferedreader to get the contents of the story.txt file
			//and put each line into that arraylist
			int x = 0;
			String line = null;
			FileReader fr = new FileReader("story.txt");
			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null)
	        {
	            allStory.add(x, line);
	            x++;
	        }
	        br.close();//Close the buffered reader
		}catch (IOException e){}
		

		while(gameOn){//
			String[] currentStoryData = allStory.get(currentChap).split(",,");

			StoryEvent story = new StoryEvent(currentStoryData[0], currentStoryData[1], currentStoryData[2], currentStoryData[3], Boolean.parseBoolean(currentStoryData[4]), Integer.parseInt(currentStoryData[5]), currentStoryData[6], currentStoryData[7], currentStoryData[8], currentStoryData[9]);
			window.setDialog(story.writeStory());  
			window.setImage(story.getImage());
			window.setSprite(story.getSprite());
			window.setNPCName(story.getNPCName());
			if (story.autoAdvance()) {	
				delay();
				currentChap = story.getNextChap();
			}
			else{
				String input = window.getInput();
				if (input.equals(story.getOption(1))) {
					System.out.println("you said "+window.getInput());
					currentChap = 4;
				}
				else if (input.equals(story.getOption(2))) {
					System.out.println("you said "+window.getInput());
					currentChap = 5;
				}
				
			}
		}		

		Date endTime = new Date();
		int numSeconds = (int)((endTime.getTime() - startTime.getTime()) / 1000);
		System.out.println("Congrats! Your time code is: "+numSeconds);
	}
}