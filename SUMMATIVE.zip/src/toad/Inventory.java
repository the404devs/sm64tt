package toad;

public class Inventory{

}